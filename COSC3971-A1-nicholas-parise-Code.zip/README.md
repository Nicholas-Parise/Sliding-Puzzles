Running the program:
* The program is simple to run, going to the main file you can easily choose which method you use to solve the puzzle.
* You can change which puzzle is solved by rearranging the puzzle to be at the top of the puzzle_input.txt file.
    * Note the numbers in puzzles must be separated by tabs.

If not using inside IDE:
* Run the compile.bat to compile.
* Run the run.bat to run the program.
